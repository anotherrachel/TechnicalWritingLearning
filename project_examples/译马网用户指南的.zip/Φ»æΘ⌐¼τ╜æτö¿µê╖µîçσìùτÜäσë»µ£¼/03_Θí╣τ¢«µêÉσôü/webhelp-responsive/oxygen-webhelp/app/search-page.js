/**
 * Load the libraries for the Search page.
 */
define(["require", "config"], function() {
    require(['nav-links-loader', 'searchAutocomplete', 'webhelp', 'search']);
});